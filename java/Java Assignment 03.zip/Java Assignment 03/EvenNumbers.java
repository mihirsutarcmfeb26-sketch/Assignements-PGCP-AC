public class EvenNumbers {
    
    public static void printEvenNumbers() {
        
        int i = 1;

        while(i <= 50){
            if(i % 2 == 0){
                System.err.println(i);
            }
            i++;
        }
    }

    public static void main(String[] args) {
        
        printEvenNumbers();
    }
}
