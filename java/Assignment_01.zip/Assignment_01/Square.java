public class Square {
    public static void main(String[]args){
        int side = 5;
        int area = side * side;
        System.out.println("Side of Square = " + side);
        System.out.println("Area of Square = " + area);
    }
}
